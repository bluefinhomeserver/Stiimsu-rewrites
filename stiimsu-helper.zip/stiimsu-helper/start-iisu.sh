#!/bin/bash
LOG=~/.cache/iisu-bridge-launcher.log
exec >> "$LOG" 2>&1
echo "===== $(date '+%F %T') launcher start ====="

IISU_PKG=com.iisulauncher
STATUS_URL=http://192.168.240.1:5987/status
TOKEN=$(cat "$HOME/Documents/iisu-bridge/token" 2>/dev/null)

iisu_running() {
    sudo -n waydroid shell -- pidof "$IISU_PKG" > /dev/null 2>&1
}
emulator_running() {
    curl -s -m 3 -X POST "$STATUS_URL" \
        -H 'Content-Type: application/json' \
        -d "{\"token\":\"$TOKEN\"}" 2>/dev/null | grep -q '"running": *true'
}

systemctl --user start iisu-bridge.service
echo "launching iiSU (waydroid handles session bring-up itself)"
nohup waydroid app launch "$IISU_PKG" > /dev/null 2>&1 &
SEEN=0
for i in $(seq 1 150); do
    if iisu_running; then SEEN=1; echo "iiSU seen after $i checks"; break; fi
    sleep 2
done
if [ "$SEEN" -ne 1 ]; then
    echo "never saw iiSU running; leaving the stack up, not tearing down"
    echo "sudo test: $(sudo -n waydroid shell -- pidof "$IISU_PKG" 2>&1; echo rc=$?)"
    exit 1
fi
while iisu_running || emulator_running; do
    sleep 5
done
echo "iiSU and emulator both gone; tearing down"
systemctl --user stop iisu-bridge.service
waydroid session stop
echo "===== $(date '+%F %T') launcher end ====="

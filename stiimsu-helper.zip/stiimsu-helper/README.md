# Stiimsu Helper

A light control panel for the **iisu-bridge** — the system that lets iiSU
(running in Waydroid on your Steam Deck) launch your **native SteamOS
emulators**. It does three things:

1. **Set up an emulator** — installs the matching "fake emulator" stub into
   Waydroid so iiSU launches the SteamOS emulator you choose, and records the
   host-side launch command.
2. **Add a game** — copies a ROM/ISO into the Waydroid media tree and makes it
   readable so iiSU can see it.
3. **Manage library** — lists everything in the roms folder (PS3 marker+folder
   pairs shown as one game) with sizes, and deletes items cleanly — including
   the read-only folders that disc extraction produces. Deleting from inside
   Android doesn't work (host-created files look system-owned there); this is
   the supported way. Remove deleted games from iiSU's library afterwards.

> Use your own **legally obtained** games and BIOS files. That's what keeps
> this project on the right side of the line — the bridge only launches
> emulators and passes them files you already own.

---

## Why it's a browser app (not a normal window)

SteamOS has a read-only system partition, so installing GUI toolkits like
Tk or Qt is painful. This tool instead uses only the Python standard library
and shows its interface in the browser you already have. File pickers use
**kdialog** (part of KDE, already on SteamOS; falls back to zenity). Nothing
extra to install.

---

## Install

From Desktop Mode, in a terminal:

```bash
cd ~/Downloads/stiimsu-helper      # wherever you unzipped it
chmod +x install.sh
./install.sh
```

That copies the app to `~/Documents/iisu-bridge/app/`, adds a **Stiimsu
Helper** entry to your application menu, and seeds `emulators.json` with
default host commands (only if you don't already have one).

Launch it from the app menu, or:

```bash
~/Documents/iisu-bridge/app/run-stiimsu-helper.sh
```

A browser tab opens at `http://127.0.0.1:8766/`. The helper **quits by
itself about 12 seconds after you close the tab** — no stray process left
behind. (Refreshing the page is fine; it won't trigger the shutdown.) You can
also stop it early with **Quit Stiimsu Helper** on the home screen. And if you
launch it while it's already running, it simply reopens the existing page.

---

## Important: use the updated daemon

The custom/host-emulator part only takes effect if your bridge daemon reads
`emulators.json`. Replace your daemon with the updated
`iisu_bridge_daemon.py` included alongside this app, then restart it:

```bash
systemctl --user restart iisu-bridge     # if you run it as a service
# or just relaunch it however you normally do
```

The daemon re-reads `~/Documents/iisu-bridge/emulators.json` on every launch,
so changes made in the GUI take effect immediately — no restart needed.

---

## Setting up an emulator

1. Pick a console.
2. The info box shows which Android package iiSU will be tricked into
   launching. Defaults are built from iiSU's own data plus a sensible SteamOS
   command — PS2 is proven; verify the others on first launch.
3. Leave **Default (recommended)**, or switch to **Custom command** to type a
   command or **Browse** to your emulator's executable. Keep `{rom}` where the
   game path should be substituted.
   For RetroArch-based commands a **core picker** appears, listing the cores
   installed in your host RetroArch (`~/.config/retroarch/cores/` or the
   flatpak's folder) — picking one rewrites the `-L` argument for you. On the
   RetroArch (multi-system) entry, "Automatic" keeps `{core}` so iiSU's
   per-game core choice is used.
4. If the command is a flatpak, a checkbox appears offering to **grant that
   flatpak access to the Waydroid folder**. Leave it ticked — flatpaks are
   sandboxed and can't read your ROMs without it (the classic symptom is the
   emulator opening but saying the file wasn't found). Non-flatpak commands
   (AppImages, plain binaries) don't need this and the checkbox greys out.
5. Click **Install stub & save emulator**. (Waydroid must be running.)
5. In iiSU, open the console, assign this emulator, and press play.

Consoles that share an emulator share one stub: GameCube/Wii both use Dolphin,
Mega Drive/Sega CD both use MdEmu, Game Boy/Game Boy Color both use the same
GB emulator. Installing either one of a pair sets both up.

---

## Adding a game

1. Pick the console (the hint lists the file types iiSU accepts for it).
2. **Browse** to your ROM/ISO.
3. **Add game to library** — it's copied to
   `~/.local/share/waydroid/data/media/0/roms/<console>/` and made readable.
4. Rescan / reopen iiSU; the game appears.

Moving files into the media tree needs the traversal-permission sudoers rule
you already set up (`/etc/sudoers.d/zz-iisu-bridge`). If ROM adding fails with
a permission error, that rule is the thing to check.

---

## When a stub doesn't launch the game

Every stub logs what it received and what the daemon said, under one tag.
Watch it live while pressing play:

```bash
sudo waydroid shell -- logcat -v brief | grep -i iisBridgeStub
```

You'll see the raw ROM value from iiSU, the normalized path, and the daemon's
HTTP response. Common fixes:

- **`HTTP 400` / unknown system** — the console isn't in the daemon's commands;
  set it in the GUI (Custom) and restart the daemon.
- **Emulator opens but no game loads** — the host command is wrong for that
  emulator; adjust it in Custom mode (check the `{rom}` position and any flags).
  For **flatpak** emulators this can also be the sandbox: grant the app access
  to `~/.local/share/waydroid` with Flatseal if it can't read the ROM folder.
- **Nothing happens in iiSU** — the stub package name may not match what iiSU
  expects for that console; that one needs a fresh intent capture (below).

Also useful — the daemon's own log:

```bash
journalctl --user -u iisu-bridge -f
```

---

## Special consoles

**PlayStation 3 (RPCS3).** RPCS3 can't play ISO files — it needs the disc
*extracted into a folder*. The **Add a game** screen handles this for you:
pick a PS3 ISO and it's automatically extracted into
`roms/ps3/GameName.ps3/` (using 7z, bsdtar, or a loop-mount — whatever the
system has) and verified to contain a PS3 disc structure. Note the ISO must
be a **decrypted** dump; encrypted dumps extract fine but won't boot until
decrypted (PS3Dec + key). Already-extracted game folders can be dropped into
`roms/ps3/` by hand, named `Something.ps3`. The daemon accepts folder ROMs.

**RetroArch (multi-system).** One stub covers every console you assign
RetroArch to inside iiSU. The stub reports which core iiSU chose; the daemon
maps known cores to your dedicated systems (see `CORE_TO_SYSTEM`) and plays
everything else through host RetroArch with the equivalent Linux core — which
must be installed in host RetroArch (Online Updater → Core Downloader).

**Windows-only emulators (Xenia, BigPEmu).** These have no Linux build, so the
default/custom command needs `wine` (or a Proton wrapper) in front of the
`.exe` path — the Xbox 360 default shows the shape. Adjust to your install.

---

## What's in the folder

```
stiimsu-helper/
  stiimsu_helper.py          the app (backend + embedded UI)
  run-stiimsu-helper.sh      launcher
  install.sh                 installer + menu entry
  data/
    consoles.json            console list, iiSU identities, defaults
    emulators.default.json   default host commands
    apks/                    20 pre-built stub APKs
```

All stubs are signed with the same key. The bridge token is generated fresh
for every install by `install.sh` and read by the stubs at launch from a
synced copy inside the game library — no shared secrets between installs, no
extra setup.

# iisu-bridge — Full Setup Guide (Steam Deck / SteamOS)

Run the **iiSU** Android game frontend on your Steam Deck, but have every game
launch a **native SteamOS emulator** — PCSX2, Dolphin, RPCS3, RetroArch and
friends — instead of an Android one. iiSU is your couch-friendly library; your
real Linux emulators do the playing.

How it works, in one breath: iiSU runs inside **Waydroid** (an Android
container). When you press play, a tiny **stub APK** impersonating the Android
emulator catches the launch, and sends the game's path to a small **daemon**
on the SteamOS side, which translates the path and starts your native
emulator. A control-panel web app, **Stiimsu Helper**, manages all of it.

> **Play fair:** use your own legally obtained games and BIOS files, dumped
> from hardware you own. This project only launches emulators and hands them
> files you already have — that's what keeps it (and you) on the right side
> of the line.

**What's in this bundle**

```
stiimsu-helper/
  SETUP.md                   this guide
  stiimsu_helper.py          the Stiimsu Helper app (backend + UI)
  run-stiimsu-helper.sh      launcher for the app
  install.sh                 installer (app + daemon + menu entry)
  iisu_bridge_daemon.py      the bridge daemon
  tools/ps3dec               static PS3 ISO decrypter (see PS3 section)
  data/
    consoles.json            console list + iiSU identities
    emulators.default.json   default host commands
    apks/                    20 pre-built stub APKs
```

Supported consoles: PS1, PS2, PS3, PSP, GameCube, Wii, Wii U, N64, SNES,
Game Boy / Color / Advance, DS, 3DS, Mega Drive, Sega CD, Saturn, Dreamcast,
Atari 2600, Atari Jaguar, Xbox, Xbox 360, plus RetroArch as a multi-system
option. (PS Vita is **not** supported — its install-and-license model doesn't
fit this pipeline.)

---

## 1. Prepare SteamOS

Everything happens in **Desktop Mode** (Steam button → Power → Switch to
Desktop). Open the **Konsole** terminal for the commands below.

If you have never set a password for the `deck` user, do it now — several
steps need `sudo`:

```bash
passwd
```

## 2. Install Waydroid

Waydroid is the Android container that hosts iiSU. On SteamOS the reliable
route is the community **SteamOS Waydroid Installer** (search GitHub for
`SteamOS-Waydroid-Installer` by ryanrudolfoba) — it handles SteamOS's
read-only filesystem and the Android image download for you. Follow its
README, then launch Waydroid once so it finishes first-boot setup and creates
its data folders.

Sanity check when done:

```bash
waydroid status        # should say the session is RUNNING while Waydroid is open
ls ~/.local/share/waydroid/data/media/0/    # Android's /sdcard, on the host side
```

## 3. Install iiSU into Waydroid

Get the iiSU APK from the iiSU project, then (with the Waydroid session
running):

```bash
waydroid app install ~/Downloads/iiSU_*.apk
```

Give iiSU full storage access so it can see your game library (this persists
permanently):

```bash
sudo waydroid shell -- appops set com.iisulauncher MANAGE_EXTERNAL_STORAGE allow
```

Open iiSU once from Waydroid to confirm it runs. Don't configure libraries
yet — the folders don't exist until step 4.

## 4. Create the ROM library (one-time)

Games live inside Waydroid's shared storage so both worlds can see them:
`~/.local/share/waydroid/data/media/0/roms/<console>/`. That tree is
root-owned by Android, so hand yourself the `roms` part once:

```bash
sudo mkdir -p ~/.local/share/waydroid/data/media/0/roms
sudo chown -R deck:deck ~/.local/share/waydroid/data/media/0/roms
chmod a+rX ~/.local/share/waydroid/data/media/0/roms
```

After this, the Stiimsu Helper's **Add a game** screen creates per-console
subfolders and copies files for you — you never manage this tree by hand
(and don't try to manage it from *inside* Android; host-created files look
system-owned there and can't be deleted from that side).

## 5. Allow the bridge its two privileged actions

The daemon needs passwordless rights for exactly two things: driving Waydroid
(stop/relaunch iiSU during play) and re-opening the traversal permission
Android relocks on the media folders at every boot. Create the sudoers file —
the `zz-` prefix matters (sudoers files are read alphabetically and the last
match wins, so this must sort after SteamOS's own files):

```bash
sudo tee /etc/sudoers.d/zz-iisu-bridge > /dev/null << 'EOF'
deck ALL=(root) NOPASSWD: /usr/bin/waydroid
deck ALL=(root) NOPASSWD: /usr/bin/chmod o+x /home/deck/.local/share/waydroid/data
deck ALL=(root) NOPASSWD: /usr/bin/chmod o+x /home/deck/.local/share/waydroid/data/media
deck ALL=(root) NOPASSWD: /usr/bin/chmod o+x /home/deck/.local/share/waydroid/data/media/0
EOF
sudo chmod 440 /etc/sudoers.d/zz-iisu-bridge
```

The chmod lines are argument-exact on purpose: the bridge can open the
execute bit on those three directories and do nothing else.

## 6. Install the bridge and the Helper

Unzip this bundle and run the installer:

```bash
cd ~/Downloads/stiimsu-helper
chmod +x install.sh
./install.sh
```

This copies the app to `~/Documents/iisu-bridge/app/`, deploys the daemon to
`~/Documents/iisu-bridge/iisu_bridge_daemon.py`, **generates a unique random
bridge token** at `~/Documents/iisu-bridge/token` (kept on re-runs), seeds
`~/Documents/iisu-bridge/emulators.json` with defaults (kept and merged on
future re-runs, never overwritten), and adds **Stiimsu Helper** to your app
menu. Re-running `install.sh` is also how you update later.

## 7. Create the daemon service

The daemon runs as a systemd *user* service, started on demand by the
launcher (it does not auto-start at boot):

```bash
mkdir -p ~/.config/systemd/user
tee ~/.config/systemd/user/iisu-bridge.service > /dev/null << 'EOF'
[Unit]
Description=iiSU bridge daemon (Waydroid frontend -> native SteamOS emulators)

[Service]
ExecStart=/usr/bin/python3 /home/deck/Documents/iisu-bridge/iisu_bridge_daemon.py
Restart=on-failure
EOF
systemctl --user daemon-reload
```

Its log is your best friend later: `journalctl --user -u iisu-bridge -f`
narrates every launch request, path translation, and emulator start.

## 8. The one-click launcher

This script boots the whole stack straight into iiSU and tears everything
down when you're done — daemon up, iiSU launched in its own window (no
Android home screen), then it waits until both iiSU and any running game are
gone before stopping the daemon and the Waydroid session:

```bash
tee ~/Documents/iisu-bridge/start-iisu.sh > /dev/null << 'EOF'
#!/bin/bash
LOG=~/.cache/iisu-bridge-launcher.log
exec >> "$LOG" 2>&1
echo "===== $(date '+%F %T') launcher start ====="

IISU_PKG=com.iisulauncher
STATUS_URL=http://192.168.240.1:5987/status
TOKEN=$(cat "$HOME/Documents/iisu-bridge/token" 2>/dev/null)

iisu_running() {
    sudo -n waydroid shell -- pidof "$IISU_PKG" > /dev/null 2>&1
}
emulator_running() {
    curl -s -m 3 -X POST "$STATUS_URL" \
        -H 'Content-Type: application/json' \
        -d "{\"token\":\"$TOKEN\"}" 2>/dev/null | grep -q '"running": *true'
}

systemctl --user start iisu-bridge.service
echo "launching iiSU (waydroid handles session bring-up itself)"
nohup waydroid app launch "$IISU_PKG" > /dev/null 2>&1 &
SEEN=0
for i in $(seq 1 150); do
    if iisu_running; then SEEN=1; echo "iiSU seen after $i checks"; break; fi
    sleep 2
done
if [ "$SEEN" -ne 1 ]; then
    echo "never saw iiSU running; leaving the stack up, not tearing down"
    echo "sudo test: $(sudo -n waydroid shell -- pidof "$IISU_PKG" 2>&1; echo rc=$?)"
    exit 1
fi
while iisu_running || emulator_running; do
    sleep 5
done
echo "iiSU and emulator both gone; tearing down"
systemctl --user stop iisu-bridge.service
waydroid session stop
echo "===== $(date '+%F %T') launcher end ====="
EOF
chmod +x ~/Documents/iisu-bridge/start-iisu.sh
```

Give it a menu entry (and this is also what you add to Steam):

```bash
tee ~/.local/share/applications/iisu-frontend.desktop > /dev/null << 'EOF'
[Desktop Entry]
Type=Application
Name=iiSU Frontend
Comment=Android game frontend bridged to native SteamOS emulators
Exec=/home/deck/Documents/iisu-bridge/start-iisu.sh
Terminal=false
Categories=Game;
EOF
```

The launcher starts iiSU with the exact same command as Waydroid's own
generated app shortcuts, so session bring-up and the app window are handled
by Waydroid itself. A cold first Android boot can take a few minutes before
iiSU appears — the launcher waits up to five, and never shuts anything down
unless it actually saw iiSU running. It never shuts anything down unless it actually saw iiSU running, and
it writes a step-by-step log to `~/.cache/iisu-bridge-launcher.log` — if a
launch ever misbehaves, that log names the failing step.

For **Gaming Mode**: in Steam (Desktop Mode) → Games → *Add a Non-Steam Game
to My Library* → pick **iiSU Frontend**. Verify it works in Desktop Mode
first; Gaming Mode support depends on your Waydroid installer's session
setup.

## 9. Install your emulators

The bridge launches whatever you have; it doesn't ship emulators. Two
conventions make life easy:

Flatpaks (from Discover) work out of the box for most systems — DuckStation,
Dolphin, PPSSPP, Flycast, RPCS3, Cemu, Azahar, mGBA, DeSmuME, Stella, xemu.
The Helper knows their default launch commands.

AppImages go in `~/Applications/`, made executable, ideally with a
version-proof symlink you point commands at:

```bash
chmod +x ~/Applications/YourEmu-v1.2.3.AppImage
ln -sf ~/Applications/YourEmu-v1.2.3.AppImage ~/Applications/youremu-stable
```

The Helper auto-detects AppImages here: if a console's default flatpak isn't
installed but a matching AppImage exists, the default command adapts to it.
For RetroArch, download the cores you want inside RetroArch itself (Online
Updater → Core Downloader); if you use the AppImage build, symlink its
portable cores folder to the standard location so the bridge finds them:

```bash
mkdir -p ~/.config/retroarch
ln -s ~/Applications/RetroArch-*/RetroArch-*.AppImage.home/.config/retroarch/cores \
      ~/.config/retroarch/cores 2>/dev/null || true
```

Two Windows-only emulators need a `wine`/Proton wrapper you configure
yourself via Custom command: **Xenia** (Xbox 360) and **BigPEmu** (Jaguar —
or use the RetroArch VirtualJaguar default instead).

## 10. Using Stiimsu Helper

Launch **Stiimsu Helper** from the app menu (Waydroid should be running when
installing stubs). It opens in your browser, quits itself when you close the
tab, and shows its version in the footer. Three screens:

**Set up an emulator.** Pick a console. The info box shows which Android
package iiSU will be tricked into seeing. Keep the **Default** command, or
switch to **Custom** and Browse to your emulator (keep `{rom}` where the game
path goes). A live checkmark under the command tells you whether the
executable actually exists *before* you save. RetroArch-based commands get a
**core picker** listing your installed cores. If the command is a flatpak, a
checkbox offers to grant it access to the Waydroid folder — leave it ticked;
sandboxed flatpaks otherwise open and claim the file doesn't exist. Click
**Install stub & save emulator**: the command saves instantly (the daemon
picks it up with no restart) and the stub APK installs into Waydroid, where
it's automatically granted storage-read access so it can pick up your bridge
token from the library folder.

**Add a game.** Pick the console, Browse to your ROM/ISO, click Add. The file
is copied into the library and made readable. **PS3 is special** — see below.

**Manage library.** Lists everything in the roms tree with sizes (PS3
marker+folder pairs shown as one game) and deletes cleanly, including the
read-only folders disc extraction produces. This is the supported way to
delete games — doing it from inside Android does not work.

### PS3 games

RPCS3 cannot play ISO files — it needs the disc *extracted*. The Helper does
this automatically: pick a PS3 ISO in **Add a game** and it's extracted into
`roms/ps3/Game.ps3.dir/`, with a small `Game.ps3` marker file written beside
it — the marker is what iiSU shows as the game, and the daemon redirects it
to the real boot file at launch.

The catch: the ISO must be a **decrypted** dump. PC-made (redump-style) ISOs
are encrypted and come with a `.dkey` file holding the disc key. Decrypt
first with the bundled static `ps3dec` (no dependencies, runs on stock
SteamOS):

```bash
chmod +x ~/Downloads/stiimsu-helper/tools/ps3dec
~/Downloads/stiimsu-helper/tools/ps3dec d key <32-hex-key-from-the-.dkey-file> \
    encrypted.iso decrypted.iso
```

Then add `decrypted.iso` through the Helper. Also boot the game once directly
in RPCS3 (File → Boot Game → the extracted folder) the first time — RPCS3
needs its firmware installed (`PS3UPDAT.PUP` via File → Install Firmware),
and proving the game boots there isolates any problem from the bridge.

## 11. Configure iiSU and play

Inside iiSU, for each console: add the library folder — point its folder
picker at `roms/<console>` under internal storage — and assign the emulator
matching the stub you installed (e.g. AetherSX2 for PS2, DuckStation for PS1,
Dolphin for GameCube/Wii, APS3E for PS3, RetroArch for anything you routed
that way; the Helper's info box names each one). Then press play: iiSU
launches the stub, the stub calls the daemon, your native emulator opens over
Waydroid, and iiSU quietly closes during play and returns when you exit the
game.

One Android quirk to know: files added from the host aren't visible to
Android's media index until the **Waydroid session restarts**. If a freshly
added game doesn't appear in iiSU's picker, close everything (the launcher
tears the session down when iiSU exits) and start again — then add/rescan the
game in iiSU.

## 12. Updating

Download the new bundle, then:

```bash
pkill -f stiimsu_helper
cd ~/Downloads && rm -rf stiimsu-helper && unzip stiimsu-helper.zip
cd stiimsu-helper && ./install.sh
```

`install.sh` updates the app, deploys the daemon and restarts its service,
and merges any new console defaults into your `emulators.json` without
touching your customizations. Hard-refresh the Helper tab (Ctrl+Shift+R) and
check the version in the footer.

## 13. Troubleshooting

The two windows that explain everything: the daemon's journal
(`journalctl --user -u iisu-bridge -f`) shows `[req]`, `[unwrap]`, `[ps3]`,
`[launch]`, `[reject]` lines for every play press; and the stubs' Android log
(`sudo waydroid shell -- logcat -v brief | grep -i iisBridgeStub`) shows what
iiSU sent and what the daemon answered.

Common cases, learned the hard way:

*Emulator opens but "file not found"* — a flatpak sandbox problem. Re-run the
emulator setup with the sandbox checkbox ticked, or manually:
`flatpak override --user <app-id> --filesystem=~/.local/share/waydroid`.

*Toast says "emulator executable not found"* — the saved command points at a
moved/deleted binary (this is why the stable-symlink convention exists). Open
the console in the Helper; the checkmark line names the problem.

*"rom not found"* — the journal's `[reject]` line prints the exact android
path, host path, and whether it exists; the answer is in it.

*Game added but not in iiSU* — Android's stale media index; restart the
Waydroid session and re-add/rescan in iiSU. iiSU also caches per-file
entries: if a file was replaced, remove and re-add the game in iiSU.

*"emulator already running" (409)* — a previous game is still open; the
bridge runs one at a time.

*No sound in Android/iiSU* — check KDE's volume tray: Waydroid gets its own
per-app channel and it's easy to mute it by accident.

*RetroArch launches nothing* — the core isn't installed in the host
RetroArch, or the command points at a RetroArch you don't have (flatpak vs
AppImage). The core picker and checkmark line in the Helper resolve both.

*iiSU shows a stale error from a previous attempt* — iiSU sometimes redisplays
the last emulator error; check the journal timestamps before chasing it.

## 14. Security note

Every install uses its own **random bridge token**. `install.sh` generates it
at `~/Documents/iisu-bridge/token` (the Helper re-creates it if missing), the
daemon and launcher read it from there, and the Helper keeps a synced copy at
`roms/iisu-bridge.token` inside the game library, which is where the stubs
read it from at launch — that's why stub installs grant them Android's
storage-read permission. Treat the token file as private to your Deck. To
rotate it, delete `~/Documents/iisu-bridge/token` and re-run `install.sh`;
running stubs pick the new value up on their next launch, no reinstall
needed.

The rest of the model: the daemon listens only on the Waydroid-internal
interface (`192.168.240.1`) — never your network — and only ever runs
whitelisted emulator commands against validated library paths. The Helper
accepts requests only from the local machine (Host/Origin checked) and quits
itself when its tab closes. Don't change the daemon's bind address to
`0.0.0.0`.

---

Built with iiSU's blessing, for people who want their Android-style game
library and their real Linux emulators at the same time. Enjoy.

#!/usr/bin/env bash
set -e

SRC="$(dirname "$(readlink -f "$0")")"
BRIDGE_DIR="$HOME/Documents/iisu-bridge"
APP_DIR="$BRIDGE_DIR/app"

echo "Installing Stiimsu Helper into $APP_DIR"
mkdir -p "$BRIDGE_DIR"
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR"
cp -r "$SRC/stiimsu_helper.py" "$SRC/run-stiimsu-helper.sh" "$SRC/data" "$APP_DIR/"
chmod +x "$APP_DIR/run-stiimsu-helper.sh"

if [ ! -f "$BRIDGE_DIR/emulators.json" ]; then
    cp "$SRC/data/emulators.default.json" "$BRIDGE_DIR/emulators.json"
    echo "  seeded $BRIDGE_DIR/emulators.json with default host commands"
else
    python3 - "$BRIDGE_DIR/emulators.json" "$SRC/data/emulators.default.json" <<'PY'
import json, sys
cur = json.load(open(sys.argv[1]))
added = [k for k, v in json.load(open(sys.argv[2])).items()
         if cur.setdefault(k, v) is v and k not in ()] 
json.dump(cur, open(sys.argv[1], "w"), indent=1)
PY
    echo "  kept your emulators.json, merged in defaults for any new consoles"
fi

cp "$SRC/iisu_bridge_daemon.py" "$BRIDGE_DIR/iisu_bridge_daemon.py"
if systemctl --user list-unit-files 2>/dev/null | grep -q '^iisu-bridge'; then
    systemctl --user try-restart iisu-bridge.service 2>/dev/null || true
    echo "  deployed bridge daemon and restarted the iisu-bridge service"
else
    echo "  deployed bridge daemon to $BRIDGE_DIR (no service found to restart)"
fi

if [ ! -f "$BRIDGE_DIR/token" ]; then
    python3 -c 'import secrets; print(secrets.token_urlsafe(48))' > "$BRIDGE_DIR/token"
    chmod 600 "$BRIDGE_DIR/token"
    echo "  generated a unique bridge token"
else
    echo "  kept your existing bridge token"
fi
ROMS_DIR="$HOME/.local/share/waydroid/data/media/0/roms"
if [ -d "$ROMS_DIR" ]; then
    cp "$BRIDGE_DIR/token" "$ROMS_DIR/iisu-bridge.token"
    chmod 644 "$ROMS_DIR/iisu-bridge.token"
    echo "  synced token into the game library for the stubs"
fi

APPS="$HOME/.local/share/applications"
mkdir -p "$APPS"
cat > "$APPS/stiimsu-helper.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Stiimsu Helper
Comment=Set up iisu-bridge emulators and add games
Exec=$APP_DIR/run-stiimsu-helper.sh
Terminal=false
Categories=Game;Utility;
EOF
chmod +x "$APPS/stiimsu-helper.desktop" 2>/dev/null || true
update-desktop-database "$APPS" 2>/dev/null || true

echo
echo "Done. Launch it from your app menu ('Stiimsu Helper'), or run:"
echo "  $APP_DIR/run-stiimsu-helper.sh"

#!/usr/bin/env python3

import json
import os
import re
import secrets
import shlex
import shutil
import subprocess
import threading
import time
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOME = os.path.expanduser("~")
BRIDGE_DIR = os.path.join(HOME, "Documents", "iisu-bridge")
EMU_JSON = os.path.join(BRIDGE_DIR, "emulators.json")
MEDIA_ROMS = os.path.join(HOME, ".local/share/waydroid/data/media/0/roms")
MEDIA_PARENTS = [
    os.path.join(HOME, ".local/share/waydroid/data"),
    os.path.join(HOME, ".local/share/waydroid/data/media"),
    os.path.join(HOME, ".local/share/waydroid/data/media/0"),
]

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, "data")
CONSOLES_JSON = os.path.join(DATA_DIR, "consoles.json")
APK_DIR = os.path.join(DATA_DIR, "apks")

VERSION = "1.7"

HOST = "127.0.0.1"
PORT = 8766


GRACE = float(os.environ.get("STIIMSU_GRACE", "12"))
_heartbeat = {"last": 0.0, "seen": False}


def load_consoles():
    with open(CONSOLES_JSON) as f:
        return json.load(f)


def load_emu():
    if os.path.isfile(EMU_JSON):
        try:
            return json.load(open(EMU_JSON))
        except Exception:
            return {}
    return {}


def save_emu(d):
    os.makedirs(BRIDGE_DIR, exist_ok=True)
    with open(EMU_JSON, "w") as f:
        json.dump(d, f, indent=1)


def waydroid_session_up():
    try:
        r = subprocess.run(["waydroid", "status"], capture_output=True,
                           text=True, timeout=8)
        return "RUNNING" in r.stdout
    except Exception:
        return False


def ensure_traversal_perms():
    for d in MEDIA_PARENTS:
        try:
            subprocess.run(["sudo", "-n", "/usr/bin/chmod", "o+x", d],
                           capture_output=True, timeout=10)
        except Exception:
            pass


def native_pick(want_dir=False):
    home = HOME
    tries = []
    if shutil.which("kdialog"):
        if want_dir:
            tries.append(["kdialog", "--getexistingdirectory", home])
        else:
            tries.append(["kdialog", "--getopenfilename", home])
    if shutil.which("zenity"):
        z = ["zenity", "--file-selection"]
        if want_dir:
            z.append("--directory")
        tries.append(z)
    for cmd in tries:
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            path = r.stdout.strip()
            if r.returncode == 0 and path:
                return path
        except Exception:
            continue
    return None


def flatpak_id_of(cmd_list):
    if not cmd_list or cmd_list[0] != "flatpak" or "run" not in cmd_list:
        return None
    for tok in cmd_list[cmd_list.index("run") + 1:]:
        if not tok.startswith("-"):
            return tok
    return None


def grant_waydroid_access(app_id):
    target = os.path.join(HOME, ".local/share/waydroid")
    try:
        r = subprocess.run(["flatpak", "override", "--user", app_id,
                            f"--filesystem={target}"],
                           capture_output=True, text=True, timeout=20)
        if r.returncode == 0:
            return True, f"granted {app_id} access to {target}"
        return False, (r.stderr or r.stdout).strip() or f"rc={r.returncode}"
    except FileNotFoundError:
        return False, "flatpak not found on this system"
    except Exception as e:
        return False, str(e)


def list_retroarch_cores():
    dirs = [
        os.path.join(HOME, ".config/retroarch/cores"),
        os.path.join(HOME, ".var/app/org.libretro.RetroArch/config/retroarch/cores"),
    ]
    seen = {}
    for d in dirs:
        try:
            for f in sorted(os.listdir(d)):
                if f.endswith(".so") and f not in seen:
                    seen[f] = os.path.join(d, f)
        except Exception:
            continue
    return [{"file": f, "path": p,
             "name": f.replace("_libretro.so", "").replace(".so", "")}
            for f, p in seen.items()]


def validate_tokens(toks):
    if not toks:
        return {"ok": False, "msg": "empty command"}
    exe = toks[0]
    if exe == "flatpak":
        app = flatpak_id_of(toks)
        if not app:
            return {"ok": False, "msg": "flatpak command without an app id"}
        try:
            r = subprocess.run(["flatpak", "info", app],
                               capture_output=True, timeout=10)
            if r.returncode != 0:
                return {"ok": False,
                        "msg": f"{app} could NOT be automatically found — "
                               "Browse for emulator executable instead"}
            base_ok = f"flatpak {app} is installed"
        except FileNotFoundError:
            return {"ok": False, "msg": "flatpak isn't available on this system"}
        except Exception as e:
            return {"ok": False, "msg": f"could not check flatpak: {e}"}
    elif "/" in exe:
        if not os.path.exists(exe):
            return {"ok": False,
                    "msg": f"{exe} could NOT be found — Browse for emulator "
                           "executable instead"}
        if not os.access(exe, os.X_OK):
            return {"ok": False,
                    "msg": f"{exe} is not executable — run: chmod +x '{exe}'"}
        base_ok = f"{os.path.basename(exe)} found"
    else:
        w = shutil.which(exe)
        if not w:
            return {"ok": False,
                    "msg": f"'{exe}' could NOT be automatically found — Browse "
                           "for emulator executable instead"}
        base_ok = f"{exe} found ({w})"


    if "-L" in toks:
        i = toks.index("-L")
        if i + 1 < len(toks):
            core = toks[i + 1]
            if core != "{core}":
                if "/" not in core:
                    return {"ok": False,
                            "msg": f"core '{core}' is a bare name — use the "
                                   "core picker so it becomes a full path"}
                if not os.path.isfile(core):
                    return {"ok": False, "msg": f"core file missing: {core}"}
    return {"ok": True, "msg": base_ok}


import glob


def _flatpak_installed(app_id):
    try:
        return subprocess.run(["flatpak", "info", app_id], capture_output=True,
                              timeout=10).returncode == 0
    except Exception:
        return False


def _find_appimage(patterns):
    cands = []
    for pat in (os.path.join(HOME, "Applications", "*"),
                os.path.join(HOME, "Applications", "*", "*")):
        for p in glob.glob(pat):
            base = os.path.basename(p).lower()
            if (os.path.isfile(p) and os.access(p, os.X_OK)
                    and any(k in base for k in patterns)
                    and (base.endswith(".appimage") or "stable" in base)):
                cands.append(p)
    cands.sort(key=lambda p: ("stable" not in os.path.basename(p).lower(), p))
    return cands[0] if cands else None


_APPIMAGE_HINTS = {
    "org.libretro.RetroArch": ["retroarch"],
    "net.rpcs3.RPCS3": ["rpcs3"],
    "org.duckstation.DuckStation": ["duckstation"],
    "org.DolphinEmu.dolphin-emu": ["dolphin"],
    "org.ppsspp.PPSSPP": ["ppsspp"],
    "org.flycast.Flycast": ["flycast"],
    "io.github.stella_emu.Stella": ["stella"],
    "app.xemu.xemu": ["xemu"],
    "org.azahar_emu.Azahar": ["azahar"],
    "info.cemu.Cemu": ["cemu"],
    "org.desmume.DeSmuME": ["desmume"],
    "io.mgba.mGBA": ["mgba"],
}


def adapt_defaults(consoles):
    flatpak_ok = {}
    cores_dir = os.path.join(HOME, ".config/retroarch/cores")
    for c in consoles:
        cmd = c["host_cmd"]
        if cmd[:2] != ["flatpak", "run"] or len(cmd) < 3:
            continue
        app = cmd[2]
        if app not in flatpak_ok:
            flatpak_ok[app] = _flatpak_installed(app)
        if flatpak_ok[app]:
            continue
        hints = _APPIMAGE_HINTS.get(app)
        found = _find_appimage(hints) if hints else None
        if not found:
            continue
        cmd = [found] + cmd[3:]
        if "-L" in cmd:
            i = cmd.index("-L") + 1
            if i < len(cmd) and cmd[i] != "{core}":
                base = os.path.basename(cmd[i])
                for suf in ("_libretro.so", ".so"):
                    if base.endswith(suf):
                        base = base[: -len(suf)]
                        break
                if base.endswith("_libretro"):
                    base = base[: -len("_libretro")]
                cand = os.path.join(cores_dir, base + "_libretro.so")
                if os.path.isfile(cand):
                    cmd[i] = cand
        c["host_cmd"] = cmd
    return consoles


def _human_size(n):
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return (f"{n:.1f} {u}" if u != "B" else f"{int(n)} {u}")
        n /= 1024


def _du(d):
    total = 0
    for root, _dirs, files in os.walk(d, onerror=lambda e: None):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def _wipe_dir_contents(d):
    for e in os.listdir(d):
        p = os.path.join(d, e)
        shutil.rmtree(p, ignore_errors=True) if os.path.isdir(p) else os.remove(p)


def _extract_ps3_iso(src_iso, dest):
    os.makedirs(dest, exist_ok=True)
    attempts = []

    def filled():
        return bool(os.listdir(dest))

    for tool in ("7z", "7zz"):
        if not shutil.which(tool):
            continue
        r = subprocess.run([tool, "x", "-y", f"-o{dest}", src_iso],
                           capture_output=True, text=True, timeout=7200)
        if r.returncode == 0 and filled():
            attempts.append(f"{tool}: extracted")
            return True, attempts
        attempts.append(f"{tool}: failed (rc={r.returncode})")
        _wipe_dir_contents(dest)
        break

    if shutil.which("bsdtar"):
        r = subprocess.run(["bsdtar", "-xf", src_iso, "-C", dest],
                           capture_output=True, text=True, timeout=7200)
        if r.returncode == 0 and filled():
            attempts.append("bsdtar: extracted")
            return True, attempts
        attempts.append("bsdtar: failed (likely UDF, which bsdtar can't read)")
        _wipe_dir_contents(dest)

    if shutil.which("udisksctl"):
        loopdev = mnt = None
        try:
            r = subprocess.run(["udisksctl", "loop-setup", "-r", "-f", src_iso],
                               capture_output=True, text=True, timeout=60)
            m = re.search(r"(/dev/loop\d+)", r.stdout + r.stderr)
            if not m:
                attempts.append("udisksctl: loop-setup failed")
                return False, attempts
            loopdev = m.group(1)
            r = subprocess.run(["udisksctl", "mount", "-b", loopdev],
                               capture_output=True, text=True, timeout=60)
            m = re.search(r"at ([^\s`']+?)\.?(?:\s|$)", r.stdout + r.stderr)
            if not m:
                r = subprocess.run(["findmnt", "-rn", "-o", "TARGET",
                                    "-S", loopdev],
                                   capture_output=True, text=True, timeout=15)
                mnt = r.stdout.strip() or None
            else:
                mnt = m.group(1)
            if not mnt:
                attempts.append("udisksctl: mounted but mountpoint not found")
                return False, attempts
            shutil.copytree(mnt, dest, dirs_exist_ok=True)
            attempts.append("udisksctl loop-mount: extracted")
            return True, attempts
        except Exception as e:
            attempts.append(f"udisksctl: {e}")
            _wipe_dir_contents(dest)
            return False, attempts
        finally:
            if mnt and loopdev:
                subprocess.run(["udisksctl", "unmount", "-b", loopdev],
                               capture_output=True, timeout=60)
            if loopdev:
                subprocess.run(["udisksctl", "loop-delete", "-b", loopdev],
                               capture_output=True, timeout=30)

    if not attempts:
        attempts.append("no extraction tool available (7z, bsdtar, udisksctl)")
    return False, attempts


def list_library():
    items = []
    if not os.path.isdir(MEDIA_ROMS):
        return items
    for con in sorted(os.listdir(MEDIA_ROMS)):
        cdir = os.path.join(MEDIA_ROMS, con)
        if not os.path.isdir(cdir):
            continue
        names = sorted(os.listdir(cdir))
        skip = set()
        for n in names:
            if n in skip:
                continue
            p = os.path.join(cdir, n)
            if (n.endswith(".ps3") and os.path.isfile(p)
                    and (n + ".dir") in names):
                d = p + ".dir"
                items.append({"console": con, "name": n[:-4],
                              "kind": "PS3 game", "paths": [p, d],
                              "size": _human_size(_du(d))})
                skip.add(n + ".dir")
            elif os.path.isdir(p):
                items.append({"console": con, "name": n, "kind": "folder",
                              "paths": [p], "size": _human_size(_du(p))})
            else:
                try:
                    sz = os.path.getsize(p)
                except OSError:
                    sz = 0
                items.append({"console": con, "name": n, "kind": "file",
                              "paths": [p], "size": _human_size(sz)})
    return items


def delete_library_paths(paths):
    log, ok = [], True
    ensure_traversal_perms()
    root = os.path.realpath(MEDIA_ROMS)
    for p in paths:
        rp = os.path.realpath(p)
        if not (rp + os.sep).startswith(root + os.sep) or rp == root:
            log.append(f"refused (outside the roms library): {p}")
            ok = False
            continue
        try:
            if os.path.isdir(rp) and not os.path.islink(rp):
                subprocess.run(["chmod", "-R", "u+rwX", rp],
                               capture_output=True, timeout=600)
                shutil.rmtree(rp)
            elif os.path.exists(rp) or os.path.islink(rp):
                os.remove(rp)
            log.append(f"deleted {os.path.basename(rp)}")
        except FileNotFoundError:
            log.append(f"already gone: {os.path.basename(rp)}")
        except PermissionError:
            ok = False
            log.append(f"can't delete {os.path.basename(rp)} — it's owned by "
                       f"root. In a terminal run:  sudo rm -rf '{rp}'")
        except Exception as e:
            ok = False
            log.append(f"error on {os.path.basename(rp)}: {e}")
    if any(l.startswith("deleted") for l in log):
        log.append("Remember to remove the game from iiSU's library too.")
    return {"ok": ok, "log": log}


def sync_token():
    os.makedirs(BRIDGE_DIR, exist_ok=True)
    tf = os.path.join(BRIDGE_DIR, "token")
    tok = ""
    try:
        tok = open(tf).read().strip()
    except Exception:
        pass
    if not tok:
        tok = secrets.token_urlsafe(48)
        with open(tf, "w") as f:
            f.write(tok)
        os.chmod(tf, 0o600)
    try:
        dest = os.path.join(MEDIA_ROMS, "iisu-bridge.token")
        with open(dest, "w") as f:
            f.write(tok)
        os.chmod(dest, 0o644)
    except Exception:
        pass
    return tok


def find_console(consoles, label):
    return next((c for c in consoles if c["label"] == label), None)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json"):
        data = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _json_body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}")

    def _origin_ok(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        if host not in ("127.0.0.1", "localhost"):
            return False
        origin = self.headers.get("Origin")
        if origin and not (origin.startswith("http://127.0.0.1")
                           or origin.startswith("http://localhost")):
            return False
        return True

    def do_GET(self):
        if not self._origin_ok():
            return self._send(403, '{"error": "forbidden"}')
        if self.path == "/" or self.path.startswith("/index"):
            return self._send(200, PAGE, "text/html; charset=utf-8")
        if self.path == "/api/library":
            return self._send(200, json.dumps({"items": list_library()}))
        if self.path == "/api/cores":
            return self._send(200, json.dumps({"cores": list_retroarch_cores()}))
        if self.path == "/api/consoles":
            consoles = adapt_defaults(load_consoles())
            return self._send(200, json.dumps(
                {"consoles": consoles, "emulators": load_emu(),
                 "session": waydroid_session_up(), "version": VERSION}))
        return self._send(404, "{}")

    def do_POST(self):
        if not self._origin_ok():
            return self._send(403, '{"error": "forbidden"}')
        try:
            if self.path == "/api/ping":
                _heartbeat["last"] = time.time()
                _heartbeat["seen"] = True
                return self._send(200, "{}")

            if self.path == "/api/quit":
                self._send(200, json.dumps({"ok": True}))
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            if self.path == "/api/validate":
                b = self._json_body()
                try:
                    toks = shlex.split(b.get("cmd", ""))
                except ValueError as e:
                    return self._send(200, json.dumps(
                        {"ok": False, "msg": f"parse error: {e}"}))
                return self._send(200, json.dumps(validate_tokens(toks)))

            if self.path == "/api/library_delete":
                b = self._json_body()
                return self._send(200, json.dumps(
                    delete_library_paths(b.get("paths", []))))

            if self.path == "/api/browse":
                b = self._json_body()
                path = native_pick(want_dir=b.get("dir", False))
                return self._send(200, json.dumps({"path": path or ""}))

            if self.path == "/api/install_stub":
                return self._send(200, json.dumps(self._install_stub(self._json_body())))

            if self.path == "/api/move_rom":
                return self._send(200, json.dumps(self._move_rom(self._json_body())))
        except Exception as e:
            return self._send(200, json.dumps({"ok": False, "log": [f"error: {e}"]}))
        return self._send(404, "{}")


    def _install_stub(self, b):
        consoles = adapt_defaults(load_consoles())
        c = find_console(consoles, b.get("console", ""))
        log = []
        if not c:
            return {"ok": False, "log": ["unknown console"]}
        try:
            cmd_list = shlex.split(b.get("cmd", ""))
        except ValueError as e:
            return {"ok": False, "log": [f"command parse error: {e}"]}
        if not cmd_list:
            return {"ok": False, "log": ["command is empty"]}
        warn = "{rom}" not in cmd_list
        apk = os.path.join(APK_DIR, c["apk"])
        if not os.path.isfile(apk):
            return {"ok": False, "log": [f"missing APK: {apk}"]}


        sync_token()
        emu = load_emu()
        emu[c["apk_system"]] = cmd_list
        save_emu(emu)
        log.append(f"Saved host command for '{c['apk_system']}' — the daemon "
                   "uses it immediately.")
        v = validate_tokens(cmd_list)
        if not v["ok"]:
            log.append(f"  WARNING: {v['msg']}")
            log.append("  (saved anyway — fix the command or install the "
                       "emulator before playing)")
        if warn:
            log.append("  note: no {rom} placeholder \u2014 the game path won't "
                       "be passed to the emulator.")


        if b.get("grant_sandbox"):
            app_id = flatpak_id_of(cmd_list)
            if app_id:
                ok, msg = grant_waydroid_access(app_id)
                log.append(("  sandbox: " if ok else "  sandbox FAILED: ") + msg)
            else:
                log.append("  sandbox: command isn't 'flatpak run \u2026' — skipped")


        log.append(f"Installing stub for {c['label']} ({c['iisu_pkg']})\u2026")
        if not waydroid_session_up():
            log.append("  ! stub NOT installed: Waydroid isn't running. Your "
                       "command IS saved \u2014 start Waydroid and run this "
                       "again (or skip if the stub is already installed).")
            return {"ok": False, "log": log}
        try:
            r = subprocess.run(["waydroid", "app", "install", apk],
                               capture_output=True, text=True, timeout=120)
            out = (r.stdout + r.stderr).strip()
            log.append("  " + (out if out else "installed."))
            g = subprocess.run(["sudo", "-n", "waydroid", "shell", "--",
                                "pm", "grant", c["iisu_pkg"],
                                "android.permission.READ_EXTERNAL_STORAGE"],
                               capture_output=True, text=True, timeout=30)
            log.append("  storage read granted to stub (for the bridge token)."
                       if g.returncode == 0 else
                       "  storage grant failed: "
                       + ((g.stderr or g.stdout).strip()[:120] or "unknown"))
        except Exception as e:
            log.append(f"  install error: {e} \u2014 your command is still saved.")
            return {"ok": False, "log": log}

        log.append("  Done. Assign this emulator to the console inside iiSU, "
                   "then press play — the daemon picks up the change "
                   "automatically.")
        return {"ok": True, "log": log}

    def _move_rom(self, b):
        consoles = load_consoles()
        c = find_console(consoles, b.get("console", ""))
        src = (b.get("path") or "").strip()
        log = []
        if not c:
            return {"ok": False, "log": ["unknown console"]}
        if not src or not os.path.isfile(src):
            return {"ok": False, "log": ["pick a valid game file first"]}
        sync_token()
        dest_dir = os.path.join(MEDIA_ROMS, c["system"])
        log.append(f"Adding {os.path.basename(src)} \u2192 roms/{c['system']}/")
        try:
            ensure_traversal_perms()
            os.makedirs(dest_dir, exist_ok=True)

            if c["system"] == "ps3" and src.lower().endswith(".iso"):
                base = os.path.splitext(os.path.basename(src))[0]
                marker = os.path.join(dest_dir, base + ".ps3")
                dest = marker + ".dir"
                log[-1] = (f"PS3 ISO detected — extracting into "
                           f"roms/ps3/{base}.ps3.dir/ (big games take a few "
                           "minutes)…")
                ok, attempts = _extract_ps3_iso(src, dest)
                log.extend("  " + a_ for a_ in attempts)
                if not ok:
                    shutil.rmtree(dest, ignore_errors=True)
                    log.append("  Could not extract. Extract it manually into "
                               f"a folder named {name}, or install p7zip.")
                    return {"ok": False, "log": log}
                subprocess.run(["chmod", "-R", "u+rwX,go+rX", dest],
                               capture_output=True, timeout=600)


                with open(marker, "w") as f:
                    f.write(f"/sdcard/roms/ps3/{base}.ps3.dir")
                os.chmod(marker, 0o644)
                log.append(f"  wrote {base}.ps3 marker — iiSU shows it as the "
                           "game and sends its content (the game folder's "
                           "path) at launch.")
                looks_ps3 = (os.path.isdir(os.path.join(dest, "PS3_GAME"))
                             or os.path.isfile(os.path.join(dest, "PS3_DISC.SFB")))
                if looks_ps3:
                    log.append("  PS3 disc structure confirmed (PS3_GAME found).")
                else:
                    log.append("  warning: no PS3_GAME inside — is this really "
                               "a PS3 disc image?")
                log.append("  If RPCS3 won't boot it, the ISO was an encrypted "
                           "dump — decrypt it first (PS3Dec + key), then re-add.")
                log.append("  Rescan / reopen iiSU and the game should appear.")
                return {"ok": True, "log": log}

            dest = os.path.join(dest_dir, os.path.basename(src))
            shutil.copy2(src, dest)
            os.chmod(dest, 0o644)
            log.append("  copied and made readable.")
            log.append("  Rescan / reopen iiSU and the game should appear.")
            return {"ok": True, "log": log}
        except PermissionError as e:
            log.append(f"  permission error: {e}")
            log.append("  Is the chmod sudoers rule installed? See the README.")
            return {"ok": False, "log": log}
        except Exception as e:
            log.append(f"  error: {e}")
            return {"ok": False, "log": log}


PAGE = r"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Stiimsu Helper</title>
<style>
  :root{--bg:#ffffff;--fg:#111111;--muted:#6b7280;--line:#e5e7eb;--panel:#f8f9fb;
        --blue:#2563eb;--blue-d:#1e50c4;--pink:#db2777;}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--fg);font-family:system-ui,Segoe UI,Roboto,sans-serif;}
  .wrap{max-width:680px;margin:0 auto;padding:28px 20px 48px;}
  h1{font-size:24px;margin:6px 0 2px;text-align:center;font-weight:650;}
  .sub{color:var(--muted);text-align:center;margin-bottom:28px;font-size:13px;}
  .home-btn{display:block;width:100%;background:var(--bg);border:1px solid var(--line);
    color:var(--fg);font-size:16px;padding:18px 20px;border-radius:10px;cursor:pointer;
    margin:10px 0;text-align:left;border-left:4px solid var(--blue);}
  .home-btn.alt{border-left-color:var(--pink);}
  .home-btn:hover{border-color:var(--blue);}
  .home-btn.alt:hover{border-color:var(--pink);}
  .home-btn small{display:block;color:var(--muted);font-size:12px;margin-top:4px;font-weight:400;}
  .back{background:none;border:0;color:var(--blue);cursor:pointer;font-size:14px;padding:0;margin-bottom:2px;}
  label{display:block;color:var(--muted);font-size:12px;margin:16px 0 4px;}
  select,input[type=text],textarea{width:100%;background:var(--bg);color:var(--fg);
    border:1px solid var(--line);border-radius:8px;padding:10px;font-size:14px;font-family:inherit;}
  select:focus,input:focus,textarea:focus{outline:none;border-color:var(--blue);}
  textarea{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px;resize:vertical;min-height:62px;}
  select:disabled,textarea:disabled{background:var(--panel);color:var(--muted);}
  .row{display:flex;gap:8px;}
  .row .grow{flex:1;}
  .btn{background:var(--bg);color:var(--fg);border:1px solid var(--line);border-radius:8px;
    padding:10px 14px;cursor:pointer;font-size:13px;}
  .btn:hover:not(:disabled){border-color:var(--blue);color:var(--blue);}
  .btn:disabled{opacity:.45;cursor:default;color:var(--muted);}
  .btn.accent{background:var(--blue);border-color:var(--blue);color:#fff;font-weight:600;
    width:100%;padding:12px;font-size:15px;margin-top:16px;}
  .btn.accent:hover{background:var(--blue-d);color:#fff;}
  .info{background:var(--panel);border:1px solid var(--line);border-radius:8px;
    padding:11px 13px;font-size:13px;margin-top:6px;line-height:1.5;}
  .hint{color:var(--muted);font-size:12px;margin-top:6px;}
  .log{background:var(--panel);border:1px solid var(--line);color:#374151;border-radius:8px;
    padding:11px;margin-top:16px;font-family:ui-monospace,monospace;font-size:12px;
    white-space:pre-wrap;min-height:88px;max-height:220px;overflow:auto;}
  .foot{color:var(--muted);text-align:center;font-size:11px;margin-top:26px;}
  .warnbar{background:#fdf2f8;border:1px solid var(--pink);color:#9d174d;border-radius:8px;
    padding:9px 12px;font-size:12px;margin-bottom:14px;}
  .quit{background:none;border:0;color:var(--pink);cursor:pointer;font-size:12px;margin-top:10px;}
  .chk{display:flex;gap:8px;align-items:flex-start;font-size:12.5px;color:var(--fg);
    margin-top:12px;cursor:pointer;line-height:1.45;}
  .chk input{margin-top:2px;accent-color:var(--blue);}
  .chk.off{color:var(--muted);cursor:default;}
  .hidden{display:none;}
  .lib-row{display:flex;justify-content:space-between;align-items:center;gap:10px;
    border:1px solid var(--line);border-radius:8px;padding:10px 12px;margin:6px 0;}
  .lib-meta{color:var(--muted);font-size:11.5px;margin-top:2px;}
  .btn.danger{color:var(--pink);}
  .btn.danger:hover{border-color:var(--pink);color:var(--pink);}
</style></head>
<body><div class="wrap" id="app"></div>
<script>
let CONSOLES=[], EMU={}, SESSION=false, CORES=[], VER='?';
const app=document.getElementById('app');

let HB=null;
async function boot(){
  const r=await fetch('/api/consoles'); const d=await r.json();
  CONSOLES=d.consoles; EMU=d.emulators||{}; SESSION=d.session; VER=d.version||'?';
  try{const cr=await fetch('/api/cores'); CORES=(await cr.json()).cores||[];}catch(e){CORES=[];}
  home();
  HB=setInterval(()=>fetch('/api/ping',{method:'POST'}).catch(()=>{}),3000);
}
function esc(s){return (s||'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function joinCmd(a){return (a||[]).join(' ');}

function home(){
  app.innerHTML=`
    <h1>Stiimsu Helper</h1>
    <div class="sub">Bridge iiSU on Waydroid to your native SteamOS emulators</div>
    ${SESSION?'':'<div class="warnbar">Waydroid session not detected. Installing stubs needs it running — open iiSU / start Waydroid first.</div>'}
    <button class="home-btn" onclick="emuView()">Set up an emulator
      <small>Install a fake-emulator stub and pick your SteamOS emulator</small></button>
    <button class="home-btn alt" onclick="romView()">Add a game (move ROM)
      <small>Copy a ROM/ISO into the library and make it readable</small></button>
    <button class="home-btn" onclick="libView()">Manage library
      <small>See what's in the Waydroid roms folder and delete games</small></button>
    <div class="foot">Stiimsu Helper v${esc(VER)} \u2022 Use your own legally obtained games and BIOS files.<br>
      <button class="quit" onclick="quitApp()">Quit Stiimsu Helper</button></div>`;
}
async function quitApp(){
  if(HB)clearInterval(HB);
  try{await fetch('/api/quit',{method:'POST'});}catch(e){}
  document.body.innerHTML='<div class="wrap"><p style="text-align:center;color:#6b7280;margin-top:60px">'+
    'Stiimsu Helper has stopped. You can close this tab.</p></div>';
}

function emuView(){
  const opts=CONSOLES.map(c=>`<option>${esc(c.label)}</option>`).join('');
  app.innerHTML=`
    <button class="back" onclick="home()">&larr; Home</button>
    <h1 style="text-align:left;font-size:20px">Set up an emulator</h1>
    <label>Console</label>
    <select id="con">${opts}</select>
    <div class="info" id="info"></div>
    <label>SteamOS emulator</label>
    <select id="mode"><option>Default (recommended)</option><option>Custom command</option></select>
    <div id="coreRow" class="hidden"><label>RetroArch core</label>
      <select id="core" onchange="coreChanged()"></select></div>
    <textarea id="cmd" spellcheck="false"></textarea>
    <div class="hint" id="cmdStatus"></div>
    <div class="row"><button class="btn" id="browse">Browse for emulator executable…</button></div>
    <div class="hint" id="hint"></div>
    <label class="chk" id="sandboxRow"><input type="checkbox" id="sandbox">
      <span id="sandboxTxt"></span></label>
    <button class="btn accent" id="go">Install stub &amp; save emulator</button>
    <div class="log" id="log">Ready.</div>`;
  const con=document.getElementById('con');
  con.onchange=refreshEmu; document.getElementById('mode').onchange=toggleMode;
  document.getElementById('browse').onclick=async()=>{
    const p=await pick(false); if(!p)return;
    const ta=document.getElementById('cmd');
    let t=ta.value.trim().split(/\s+/).filter(Boolean);
    if(t[0]==='flatpak'&&t.includes('run')){
      let i=t.indexOf('run')+1;
      while(i<t.length&&t[i].startsWith('-'))i++;
      t=[p,...t.slice(i+1)];
    }else if(t.length){t[0]=p;}
    else t=[p,'{rom}'];
    ta.value=t.join(' ');
    updSandbox();updCore();scheduleValidate();
  };
  document.getElementById('go').onclick=install;
  document.getElementById('cmd').addEventListener('input',()=>{updSandbox();updCore();scheduleValidate();});
  refreshEmu();
}
let VTIMER=null;
function scheduleValidate(){clearTimeout(VTIMER);VTIMER=setTimeout(validateCmd,350);}
async function validateCmd(){
  const el=document.getElementById('cmdStatus'); if(!el)return;
  try{
    const r=await fetch('/api/validate',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({cmd:document.getElementById('cmd').value})});
    const d=await r.json();
    el.textContent=(d.ok?'\u2713 ':'\u2717 ')+d.msg;
    el.style.color=d.ok?'var(--blue)':'var(--pink)';
  }catch(e){el.textContent='';}
}
function raDetected(){
  const t=document.getElementById('cmd').value.trim().split(/\s+/);
  return t.some(x=>/retroarch/i.test(x));
}
function updCore(){
  const row=document.getElementById('coreRow'); if(!row)return;
  const sel=document.getElementById('core');
  const show=raDetected();
  row.classList.toggle('hidden',!show);
  if(!show)return;
  const isMulti=curCon().system==='retroarch';
  let opts='';
  if(isMulti)opts+='<option value="{core}">Automatic \u2014 iiSU picks the core per game</option>';
  opts+=CORES.map(c=>`<option value="${esc(c.path)}">${esc(c.name)}</option>`).join('');
  if(!CORES.length)opts+='<option value="" disabled>No cores found \u2014 use RetroArch\u2019s Online Updater \u2192 Core Downloader</option>';
  sel.innerHTML=opts;
  const t=document.getElementById('cmd').value.trim().split(/\s+/);
  const i=t.indexOf('-L');
  if(i>=0&&t[i+1]&&[...sel.options].some(o=>o.value===t[i+1]))sel.value=t[i+1];
}
function coreChanged(){
  const v=document.getElementById('core').value; if(!v)return;
  const mode=document.getElementById('mode');
  if(!mode.value.startsWith('Custom')){mode.value='Custom command';toggleMode();}
  const ta=document.getElementById('cmd');
  let t=ta.value.trim().split(/\s+/).filter(Boolean);
  const i=t.indexOf('-L');
  if(i>=0&&i+1<t.length)t[i+1]=v;
  else{const r=t.indexOf('{rom}');if(r>=0)t.splice(r,0,'-L',v);else t.push('-L',v);}
  ta.value=t.join(' ');
  updSandbox(); scheduleValidate();
}
function cmdFlatpakId(){
  const t=document.getElementById('cmd').value.trim().split(/\s+/);
  if(t[0]!=='flatpak'||!t.includes('run'))return null;
  for(const tok of t.slice(t.indexOf('run')+1)) if(!tok.startsWith('-')) return tok;
  return null;
}
function updSandbox(){
  const id=cmdFlatpakId();
  const box=document.getElementById('sandbox'), row=document.getElementById('sandboxRow'),
        txt=document.getElementById('sandboxTxt');
  if(id){
    box.disabled=false; box.checked=true; row.classList.remove('off');
    txt.textContent='Flatpak detected ('+id+') — grant it access to the Waydroid '+
      'folder so it can read your ROMs (fixes \u201cfile not found\u201d).';
  }else{
    box.disabled=true; box.checked=false; row.classList.add('off');
    txt.textContent='Not a flatpak command — sandbox access not needed.';
  }
}
function curCon(){const l=document.getElementById('con').value;return CONSOLES.find(c=>c.label===l);}
function refreshEmu(){
  const c=curCon();
  document.getElementById('info').innerHTML=
    `iiSU will think <b>${esc(c.iisu_pkg)}</b> is installed and launch it. `+
    `Games are routed to the SteamOS command below.`;
  const saved=EMU[c.apk_system];
  const isCustom = !!saved && joinCmd(saved)!==joinCmd(c.host_cmd);
  document.getElementById('mode').value = isCustom ? 'Custom command' : 'Default (recommended)';
  document.getElementById('cmd').value = joinCmd(saved||c.host_cmd);
  toggleMode(); updHint(); updSandbox(); updCore(); scheduleValidate();
}
function updHint(){
  const t=joinCmd(curCon().host_cmd); let h='Keep {rom} where the game path should go.';
  if(t.includes('{core}')) h='Keep {core} and {rom} in place — the stub reports which core iiSU picked, and the daemon maps it to a Linux core.';
  if(t.includes('{raw}')) h='Keep {raw} in place — for this console it receives the game\u2019s title ID (the content of your .psvita file), not a file path.';
  document.getElementById('hint').textContent=h;
}
function toggleMode(){
  const custom=document.getElementById('mode').value.startsWith('Custom');
  const ta=document.getElementById('cmd'), br=document.getElementById('browse');
  if(custom){ta.disabled=false;br.disabled=false;}
  else{ta.value=joinCmd(curCon().host_cmd);ta.disabled=true;br.disabled=true;}
  if(document.getElementById('sandbox')){updSandbox();updCore();scheduleValidate();}
}
async function install(){
  const c=curCon(); const cmd=document.getElementById('cmd').value;
  setLog('log','Working…');
  const r=await fetch('/api/install_stub',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({console:c.label,cmd,
      grant_sandbox:document.getElementById('sandbox').checked})});
  const d=await r.json(); setLog('log',(d.log||[]).join('\n'));
  if(d.ok){EMU[c.apk_system]=cmd.trim().split(/\s+/);}
}

function romView(){
  const list=CONSOLES.filter(c=>c.system!=='retroarch');
  const opts=list.map(c=>`<option>${esc(c.label)}</option>`).join('');
  app.innerHTML=`
    <button class="back" onclick="home()">&larr; Home</button>
    <h1 style="text-align:left;font-size:20px">Add a game</h1>
    <label>Console</label>
    <select id="con">${opts}</select>
    <label>Game file (ROM / ISO)</label>
    <div class="row"><input type="text" id="path" class="grow" placeholder="No file selected" readonly>
      <button class="btn" id="browse">Browse…</button></div>
    <div class="hint" id="exts"></div>
    <button class="btn accent" id="go">Add game to library</button>
    <div class="log" id="log">Ready.</div>`;
  const con=document.getElementById('con'); con.onchange=updExts; updExts();
  document.getElementById('browse').onclick=async()=>{
    const p=await pick(false); if(p)document.getElementById('path').value=p;
  };
  document.getElementById('go').onclick=async()=>{
    const c=CONSOLES.find(x=>x.label===con.value);
    const path=document.getElementById('path').value;
    setLog('log','Working…');
    const r=await fetch('/api/move_rom',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({console:c.label,path})});
    const d=await r.json(); setLog('log',(d.log||[]).join('\n'));
  };
}
function updExts(){
  const c=CONSOLES.find(x=>x.label===document.getElementById('con').value);
  let t='Accepted by iiSU for this console: '+(c.rom_exts||[]).slice(0,14).join(', ');
  if(c.system==='ps3')t+=' \u2014 ISOs are auto-extracted; iiSU will show a small \u201cName.ps3\u201d file while the game data lives in \u201cName.ps3.dir\u201d (ISO must be a decrypted dump).';
  document.getElementById('exts').textContent=t;
}

async function libView(){
  app.innerHTML=`
    <button class="back" onclick="home()">&larr; Home</button>
    <h1 style="text-align:left;font-size:20px">Manage library</h1>
    <div class="hint">Everything inside the Waydroid roms folder. Deleting here removes the files for good.</div>
    <div id="libList" style="margin-top:10px">Loading…</div>
    <div class="log" id="log">Ready.</div>`;
  await libReload();
}
async function libReload(){
  const el=document.getElementById('libList'); if(!el)return;
  try{
    const r=await fetch('/api/library'); const d=await r.json();
    LIB=d.items||[];
    if(!LIB.length){el.innerHTML='<div class="hint">Library is empty.</div>';return;}
    el.innerHTML=LIB.map((it,i)=>`
      <div class="lib-row">
        <div><b>${esc(it.name)}</b>
          <div class="lib-meta">${esc(it.console)} \u2022 ${esc(it.kind)} \u2022 ${esc(it.size)}</div></div>
        <button class="btn danger" onclick="libDel(${i})">Delete</button>
      </div>`).join('');
  }catch(e){el.textContent='Could not load library.';}
}
let LIB=[];
async function libDel(i){
  const it=LIB[i]; if(!it)return;
  if(!confirm(`Delete \u201c${it.name}\u201d (${it.console}, ${it.size})?\nThis cannot be undone.`))return;
  setLog('log','Deleting\u2026');
  const r=await fetch('/api/library_delete',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({paths:it.paths})});
  const d=await r.json(); setLog('log',(d.log||[]).join('\n'));
  await libReload();
}

async function pick(dir){
  const r=await fetch('/api/browse',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({dir})});
  const d=await r.json(); return d.path;
}
function setLog(id,t){const e=document.getElementById(id);e.textContent=t;e.scrollTop=e.scrollHeight;}
boot();
</script></body></html>
"""


def main():
    if not os.path.isfile(CONSOLES_JSON):
        raise SystemExit(f"missing data file: {CONSOLES_JSON}")
    sync_token()
    url = f"http://{HOST}:{PORT}/"
    try:
        srv = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError:

        try:
            urllib.request.urlopen(url + "api/consoles", timeout=3)
            print("Stiimsu Helper is already running — opening it.")
            webbrowser.open(url)
            return
        except Exception:
            raise SystemExit(f"Port {PORT} is in use by something else.")

    def watchdog():
        while True:
            time.sleep(2)
            if _heartbeat["seen"] and time.time() - _heartbeat["last"] > GRACE:
                print("No browser tab connected — shutting down.")
                threading.Thread(target=srv.shutdown, daemon=True).start()
                return
    threading.Thread(target=watchdog, daemon=True).start()

    print(f"Stiimsu Helper running at {url}")
    print("Quits automatically when the browser tab closes (or Ctrl+C).")
    threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")


if __name__ == "__main__":
    main()
